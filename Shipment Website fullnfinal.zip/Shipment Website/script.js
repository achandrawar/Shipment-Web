document.addEventListener("DOMContentLoaded", function () {
    if (localStorage.getItem('visited')){
        window.location = "a.html"
        //console.log("main-page");
    }
});

